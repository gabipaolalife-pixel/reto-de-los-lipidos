RETO DE LOS LÍPIDOS
Abre index.html para jugar. Funciona en computadora y celular.
Para usar un QR, primero publica index.html en un servicio de alojamiento web estático y genera el QR con la URL pública.
Texto sugerido: “Escanea el código QR y participa en el Reto de los Lípidos: una actividad interactiva para reforzar los conocimientos sobre insaturación, reacción del yodo, configuraciones cis y trans e importancia nutricional de los ácidos grasos.”
